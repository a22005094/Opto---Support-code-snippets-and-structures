echo "Stopping Kibana service..."
systemctl stop kibana.service
echo "Stopping ElasticSearch service..."
systemctl stop elasticsearch.service
